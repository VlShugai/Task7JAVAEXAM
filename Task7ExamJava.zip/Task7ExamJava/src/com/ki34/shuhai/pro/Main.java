package com.ki34.shuhai.pro;

public class Main {

    public static void main(String[] args) {
        CustomAnnotation customAnnotation = new CustomAnnotation();
        customAnnotation.doSomething();
    }
}
