package com.ki34.shuhai.pro;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;

@Retention(RetentionPolicy.RUNTIME)
@interface Once {
    int value();
}


public class CustomAnnotation {


    @Once(10)
    public void doSomething() {
        try {
            Class c = this.getClass();
            Method m = c.getMethod("doSomething");
            Once ann =
                    m.getAnnotation(Once.class);
            System.out.println(ann.value());
        } catch (NoSuchMethodException e) {
            System.out.println("метод не знайдений");
        }
    }
}
